/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HS
 */
package calculator1;

public class Calculate {
    String op[] = {"-", "+", "*", "/"};
    public static String clear(String operation){
        StringBuilder str = new StringBuilder();
        str.append(operation);
        int rem = -1;
        for (int i = 0; i < str.length(); i++) {
            rem = str.indexOf(" ");
            if(rem != -1 ){
                str.deleteCharAt(rem);
            }
        }
        
        
        
        return str.toString();
        
    }
    
    //count how many charactere your have in string
    public static int occurence (String str, char cha){
        int occ = 0;
        for(int i = 0; i < str.length(); i++){
            if(str.charAt(i) == cha){
                occ++;
            }
        }
        if (occ != 0) {
            return occ;
        }
        return 0;
    }
    
    
    //return index of start of start number
    public static int getPrevNumStart(String str, int index, String delimitor[]){
        
        int ret = -1;
        for (String string : delimitor) {
            char carac = string.charAt(0);
            for(int i = index - 1; i > -1 ; i--){
                if(str.charAt(i) == carac || (!isNum(str.charAt(i)) && ((str.charAt(i) != '.')))){
                    return i+1;
                }
            }
        }
        return -1;
        
    }

 
    //return index of end next number

    /**
     *
     * @param str
     * @param index
     * @param delimitor
     * @return
     */
   public static int getNextNumEnd(String str, int index, String delimitor[]){
        for (String string : delimitor) {
            char carac = string.charAt(0);
//            System.out.println("nextend delimitor : " + carac);
            for(int i = index + 1; i < str.length(); ++i){
//                System.out.println(str.length());
                if(str.charAt(i) == carac || (!isNum(str.charAt(i)) && str.charAt(i) != '.')){
//                    System.out.println("nextend delimitor index : " + i);
                    return i;
                }
            }
            }
            
        
        return -1;
    }
  
 public static String reduce(String string, String op, String delimitor[]){
        System.out.println("Start reduce");
        StringBuilder str = new StringBuilder();
        str.append(string);
        double res;
        int index = indexof(str.toString(), op);
        if(index != -1){
            System.out.println(str.charAt(index));
            while(indexof(str.toString(), op) != -1){
                int prev_it = getPrevNumStart(str.toString(), index, delimitor);
                int next_it = getNextNumEnd(str.toString(), index, delimitor);
                
                String a = (String) str.subSequence(prev_it, index);
                String b = (String) str.subSequence(index + 1, next_it);
                System.out.println("a : " + a);
                if(a == ""){
                    int nop = findop(str.toString(), index);
                    System.out.println("index " + nop + " length " + str.length());
                    String fop = str.substring(nop, nop+1);
                    System.out.println("next op : " + fop);
                    index = it(str.toString(), fop,index);
                    if(index == -1 )
                    {
                        return str.toString();
                    }
                    System.out.println("index " + index + " length " + str.length());
                    prev_it = getPrevNumStart(str.toString(), index, delimitor);
                    System.out.println("Prev it : " + prev_it);
                    next_it = getNextNumEnd(str.toString(), index, delimitor);
                    System.out.println("Next it : " + next_it);
                    str.delete(1, prev_it);
                    prev_it -= 1;
                    next_it -= 1;
                    index -= 1;
                    a = (String) str.subSequence(prev_it, index);
                    System.out.println("a : " + a);
                    b = (String) str.subSequence(index + 1, next_it);
                    System.out.println("b : " + b);

                    double prevNum = -Double.parseDouble(a);
                    double nextNum = Double.parseDouble(b);

                    res = calc(prevNum, nextNum, "+");

                    str.replace(prev_it, next_it, Double.toString(res));
                    System.out.println(str);
                }else if(a== "" && b == ""){
                    return str.toString();               }
                
                
                else {
                    System.out.println("b : " + b);

                    double prevNum = Double.parseDouble(a);
                    double nextNum = Double.parseDouble(b);

                    res = calc(prevNum, nextNum, op);

                    str.replace(prev_it, next_it, Double.toString(res));
                    System.out.println(str);
                }
                index = indexof(str.toString(), op);
            }
        }
        return str.toString();
    }
    


    public static int indexof(String str, String cha){
        if(cha.length() > 1 ){
            System.out.println("Error second argupment can't have more 1 caracter !");
            return -1;
        }
         for(int i =0 ; i < str.length(); i++){
            char carac = str.charAt(i);
            if(cha.charAt(0) == carac){
                return i;
            }
        }
         return  -1;
    }
    
    public static int it(String str, String cha, int index){
        if(cha.length() > 1 ){
            System.out.println("Error second argupment can't have more 1 caracter !");
            return -1;
        }
         for(int i =index+1 ; i < str.length(); i++){
            char carac = str.charAt(i);
            if(cha.charAt(0) == carac){
                return i;
            }
        }
         return  -1;
    }
    
    //check if carac is a Number
    public static boolean isNum(char charac){
        try{
            double d = Double.parseDouble(Character.toString(charac));
        }catch(NumberFormatException e)
        {
            return false;
        }
        return true;
    }
    
    /*
    public static int delimite (String operation, String delimitor){
    StringBuilder str = new StringBuilder();
    str.append(operation);
    int i = 0;
    while((!str.substring(i, i+1).equals(delimitor)) && i < str.length()){
    ++i;
    }
    return i-2;
    }*/

    private static double calc(double a, double b, String op) {
        switch(op){
            case "+":
                return a + b;
            case "-":
                return a - b;
            case "*":
                return a * b;
            case "/":
                try {
                return a / b;
                }catch(ArithmeticException e){
                    e.addSuppressed(e);
                }
            
        }
        return Double.NaN;
      
    }

    private static void Exception() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    private static int findop(String str, int start){
        String copie[] = {"+", "*", "/"};
        for(var ope : copie){
            for(int i = start + 1 ; i < str.length(); ++i){
                if(str.substring(i, i+1).equals(ope)){
                    return i;
                }
            }
        }
        return -1;
    }
}
