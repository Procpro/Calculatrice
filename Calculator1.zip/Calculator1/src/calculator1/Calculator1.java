/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculator1;

/**
 *
 * @author HS
 */
public class Calculator1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String delimitor[] = { "+", "/", "*", ">", "<"};
        // TODO code application logic here
        String operation = "<010-5*6+7/2+8*2-10/20>";
//        operation = Calculate.clear(operation);
      
        var res = Calculate.reduce(operation, "*", delimitor);
        res = Calculate.reduce(res, "/", delimitor);
        res = Calculate.reduce(res, "-", delimitor);
        res = Calculate.reduce(res, "+", delimitor);
        
          //System.out.println(operation.substring(5,6));
        System.out.println(res);
    }
    
}
